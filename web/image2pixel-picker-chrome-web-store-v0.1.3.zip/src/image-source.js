function isGoogleImagesPage(locationLike) {
  if (!locationLike?.hostname) {
    return false;
  }

  const hostname = String(locationLike.hostname).toLowerCase();

  if (!/^([a-z0-9-]+\.)*google\./.test(hostname)) {
    return false;
  }

  if (locationLike.pathname === '/imgres') {
    return true;
  }

  const search = new URLSearchParams(locationLike.search || '');
  return search.get('tbm') === 'isch';
}

function isBaiduImagesPage(locationLike) {
  if (!locationLike?.hostname) {
    return false;
  }

  const hostname = String(locationLike.hostname).toLowerCase();
  return hostname === 'image.baidu.com' || hostname.endsWith('.image.baidu.com');
}

function normalizeCandidateUrl(value, baseUrl) {
  if (!value) {
    return '';
  }

  try {
    const parsed = new URL(value, baseUrl);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:' || parsed.protocol === 'data:') {
      return parsed.toString();
    }
  } catch (_error) {
    return '';
  }

  return '';
}

function extractBaiduImageResultUrl(href, baseUrl = 'https://image.baidu.com/') {
  if (!href) {
    return '';
  }

  try {
    const parsed = new URL(href, baseUrl);
    const params = parsed.searchParams;

    return (
      normalizeCandidateUrl(params.get('objurl'), parsed)
      || normalizeCandidateUrl(params.get('imgurl'), parsed)
      || normalizeCandidateUrl(params.get('hoverURL'), parsed)
      || normalizeCandidateUrl(params.get('middleURL'), parsed)
      || ''
    );
  } catch (_error) {
    return '';
  }
}

function extractGoogleImageResultUrl(href, baseUrl = 'https://www.google.com/') {
  if (!href) {
    return '';
  }

  try {
    const parsed = new URL(href, baseUrl);
    const params = parsed.searchParams;

    return (
      normalizeCandidateUrl(params.get('imgurl'), parsed)
      || normalizeCandidateUrl(params.get('mediaurl'), parsed)
      || normalizeCandidateUrl(params.get('img'), parsed)
      || ''
    );
  } catch (_error) {
    return '';
  }
}

function collectGoogleUrlCandidates(imageElement) {
  const candidates = [];
  const pushCandidate = (value) => {
    if (value) {
      candidates.push(value);
    }
  };

  if (imageElement?.dataset) {
    pushCandidate(imageElement.dataset.ou);
    pushCandidate(imageElement.dataset.iurl);
    pushCandidate(imageElement.dataset.owurl);
    pushCandidate(imageElement.dataset.image2pixelOriginalSrc);
  }

  if (typeof imageElement?.getAttribute === 'function') {
    pushCandidate(imageElement.getAttribute('data-ou'));
    pushCandidate(imageElement.getAttribute('data-iurl'));
    pushCandidate(imageElement.getAttribute('data-owurl'));
  }

  const nearestAnchor = typeof imageElement?.closest === 'function'
    ? imageElement.closest('a[href]')
    : null;
  if (nearestAnchor?.href) {
    pushCandidate(nearestAnchor.href);
  }

  let current = imageElement?.parentElement || null;
  let depth = 0;

  while (current && depth < 4) {
    if (current.dataset) {
      pushCandidate(current.dataset.ou);
      pushCandidate(current.dataset.iurl);
      pushCandidate(current.dataset.owurl);
    }

    if (typeof current.getAttribute === 'function') {
      pushCandidate(current.getAttribute('data-ou'));
      pushCandidate(current.getAttribute('data-iurl'));
      pushCandidate(current.getAttribute('data-owurl'));
    }

    if (typeof current.querySelectorAll === 'function') {
      const anchors = Array.from(current.querySelectorAll('a[href]')).slice(0, 6);
      anchors.forEach((anchor) => pushCandidate(anchor.getAttribute('href') || anchor.href));
    }

    current = current.parentElement || null;
    depth += 1;
  }

  return candidates;
}

function collectBaiduUrlCandidates(imageElement) {
  const candidates = [];
  const pushCandidate = (value) => {
    if (value) {
      candidates.push(value);
    }
  };

  if (imageElement?.dataset) {
    pushCandidate(imageElement.dataset.objurl);
    pushCandidate(imageElement.dataset.imgurl);
    pushCandidate(imageElement.dataset.hoverUrl);
    pushCandidate(imageElement.dataset.hoverurl);
    pushCandidate(imageElement.dataset.middleurl);
    pushCandidate(imageElement.dataset.middleUrl);
    pushCandidate(imageElement.dataset.thumburl);
    pushCandidate(imageElement.dataset.thumbUrl);
    pushCandidate(imageElement.dataset.original);
    pushCandidate(imageElement.dataset.image2pixelOriginalSrc);
  }

  if (typeof imageElement?.getAttribute === 'function') {
    pushCandidate(imageElement.getAttribute('data-objurl'));
    pushCandidate(imageElement.getAttribute('data-imgurl'));
    pushCandidate(imageElement.getAttribute('data-hoverurl'));
    pushCandidate(imageElement.getAttribute('data-hover-url'));
    pushCandidate(imageElement.getAttribute('data-middleurl'));
    pushCandidate(imageElement.getAttribute('data-middle-url'));
    pushCandidate(imageElement.getAttribute('data-thumburl'));
    pushCandidate(imageElement.getAttribute('data-thumb-url'));
    pushCandidate(imageElement.getAttribute('data-original'));
  }

  const nearestAnchor = typeof imageElement?.closest === 'function'
    ? imageElement.closest('a[href]')
    : null;
  if (nearestAnchor?.href) {
    pushCandidate(nearestAnchor.href);
  }

  let current = imageElement?.parentElement || null;
  let depth = 0;

  while (current && depth < 4) {
    if (current.dataset) {
      pushCandidate(current.dataset.objurl);
      pushCandidate(current.dataset.imgurl);
      pushCandidate(current.dataset.hoverUrl);
      pushCandidate(current.dataset.hoverurl);
      pushCandidate(current.dataset.middleurl);
      pushCandidate(current.dataset.middleUrl);
      pushCandidate(current.dataset.thumburl);
      pushCandidate(current.dataset.thumbUrl);
      pushCandidate(current.dataset.original);
    }

    if (typeof current.getAttribute === 'function') {
      pushCandidate(current.getAttribute('data-objurl'));
      pushCandidate(current.getAttribute('data-imgurl'));
      pushCandidate(current.getAttribute('data-hoverurl'));
      pushCandidate(current.getAttribute('data-hover-url'));
      pushCandidate(current.getAttribute('data-middleurl'));
      pushCandidate(current.getAttribute('data-middle-url'));
      pushCandidate(current.getAttribute('data-thumburl'));
      pushCandidate(current.getAttribute('data-thumb-url'));
      pushCandidate(current.getAttribute('data-original'));
    }

    if (typeof current.querySelectorAll === 'function') {
      const anchors = Array.from(current.querySelectorAll('a[href]')).slice(0, 6);
      anchors.forEach((anchor) => pushCandidate(anchor.getAttribute('href') || anchor.href));
    }

    current = current.parentElement || null;
    depth += 1;
  }

  return candidates;
}

function resolveGoogleImagesSource(imageElement) {
  const locationLike = imageElement?.ownerDocument?.location || globalThis.location;
  if (!isGoogleImagesPage(locationLike)) {
    return '';
  }

  const baseUrl = locationLike?.href || 'https://www.google.com/';
  const candidates = collectGoogleUrlCandidates(imageElement);

  for (const candidate of candidates) {
    const extracted = extractGoogleImageResultUrl(candidate, baseUrl);
    if (extracted) {
      return extracted;
    }

    const normalized = normalizeCandidateUrl(candidate, baseUrl);
    if (normalized && !/google\./i.test(new URL(normalized).hostname)) {
      return normalized;
    }
  }

  return '';
}

function resolveBaiduImagesSource(imageElement) {
  const locationLike = imageElement?.ownerDocument?.location || globalThis.location;
  if (!isBaiduImagesPage(locationLike)) {
    return '';
  }

  const baseUrl = locationLike?.href || 'https://image.baidu.com/';
  const candidates = collectBaiduUrlCandidates(imageElement);

  for (const candidate of candidates) {
    const extracted = extractBaiduImageResultUrl(candidate, baseUrl);
    if (extracted) {
      return extracted;
    }

    const normalized = normalizeCandidateUrl(candidate, baseUrl);
    if (normalized && !/baidu\.com$/i.test(new URL(normalized).hostname)) {
      return normalized;
    }
  }

  return '';
}

function resolveOriginalImageSource(sourceState) {
  return (
    sourceState.originalDataUrl ||
    sourceState.originalSrc ||
    sourceState.googleImagesSrc ||
    sourceState.baiduImagesSrc ||
    sourceState.currentSrc ||
    sourceState.src ||
    sourceState.attributeSrc ||
    ''
  );
}

function buildSourceState(imageElement) {
  return {
    originalDataUrl: imageElement.dataset.image2pixelOriginalDataUrl || '',
    originalSrc: imageElement.dataset.image2pixelOriginalSrc || '',
    googleImagesSrc: resolveGoogleImagesSource(imageElement),
    baiduImagesSrc: resolveBaiduImagesSource(imageElement),
    currentSrc: imageElement.currentSrc || '',
    src: imageElement.src || '',
    attributeSrc: imageElement.getAttribute('src') || '',
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    buildSourceState,
    extractBaiduImageResultUrl,
    extractGoogleImageResultUrl,
    isBaiduImagesPage,
    isGoogleImagesPage,
    resolveBaiduImagesSource,
    resolveGoogleImagesSource,
    resolveOriginalImageSource,
  };
}

if (typeof globalThis !== 'undefined') {
  globalThis.ImageSourceState = {
    buildSourceState,
    extractBaiduImageResultUrl,
    extractGoogleImageResultUrl,
    isBaiduImagesPage,
    isGoogleImagesPage,
    resolveBaiduImagesSource,
    resolveGoogleImagesSource,
    resolveOriginalImageSource,
  };
}
