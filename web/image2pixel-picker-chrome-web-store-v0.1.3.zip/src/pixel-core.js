(() => {
  function detectBackgroundColor(imageData) {
    const { width, height, data } = imageData;
    const corners = [
      0,
      (width - 1) * 4,
      (height - 1) * width * 4,
      data.length - 4,
    ];

    let r = 0;
    let g = 0;
    let b = 0;
    let a = 0;

    corners.forEach((index) => {
      r += data[index];
      g += data[index + 1];
      b += data[index + 2];
      a += data[index + 3];
    });

    return [
      Math.round(r / 4),
      Math.round(g / 4),
      Math.round(b / 4),
      Math.round(a / 4),
    ];
  }

  function pixelateImageData(source, width, height, blockSize) {
    const output = new Uint8ClampedArray(source);

    for (let y = 0; y < height; y += blockSize) {
      for (let x = 0; x < width; x += blockSize) {
        let r = 0;
        let g = 0;
        let b = 0;
        let a = 0;
        let count = 0;

        for (let blockY = 0; blockY < blockSize && y + blockY < height; blockY += 1) {
          for (let blockX = 0; blockX < blockSize && x + blockX < width; blockX += 1) {
            const index = ((y + blockY) * width + (x + blockX)) * 4;
            r += output[index];
            g += output[index + 1];
            b += output[index + 2];
            a += output[index + 3];
            count += 1;
          }
        }

        const average = [
          Math.round(r / count),
          Math.round(g / count),
          Math.round(b / count),
          Math.round(a / count),
        ];

        for (let blockY = 0; blockY < blockSize && y + blockY < height; blockY += 1) {
          for (let blockX = 0; blockX < blockSize && x + blockX < width; blockX += 1) {
            const index = ((y + blockY) * width + (x + blockX)) * 4;
            output[index] = average[0];
            output[index + 1] = average[1];
            output[index + 2] = average[2];
            output[index + 3] = average[3];
          }
        }
      }
    }

    return output;
  }

  function quantizeToFixedPalette(rgba, palette) {
    for (let index = 0; index < rgba.length; index += 4) {
      let bestColor = palette[0];
      let shortestDistance = Infinity;

      palette.forEach((candidate) => {
        const distance =
          (rgba[index] - candidate[0]) ** 2 +
          (rgba[index + 1] - candidate[1]) ** 2 +
          (rgba[index + 2] - candidate[2]) ** 2;

        if (distance < shortestDistance) {
          shortestDistance = distance;
          bestColor = candidate;
        }
      });

      rgba[index] = bestColor[0];
      rgba[index + 1] = bestColor[1];
      rgba[index + 2] = bestColor[2];
    }
  }

  function removeAntiAliasing(rgba, backgroundColor, threshold = 30) {
    for (let index = 0; index < rgba.length; index += 4) {
      const distance = Math.sqrt(
        (rgba[index] - backgroundColor[0]) ** 2 +
          (rgba[index + 1] - backgroundColor[1]) ** 2 +
          (rgba[index + 2] - backgroundColor[2]) ** 2,
      );

      if (distance < threshold) {
        rgba[index] = backgroundColor[0];
        rgba[index + 1] = backgroundColor[1];
        rgba[index + 2] = backgroundColor[2];
        rgba[index + 3] = backgroundColor[3];
      }
    }
  }

  class ColorBox {
    constructor(pixels) {
      this.pixels = pixels;
      this.computeRanges();
    }

    computeRanges() {
      const min = [255, 255, 255, 255];
      const max = [0, 0, 0, 0];

      this.pixels.forEach((pixel) => {
        for (let channel = 0; channel < 4; channel += 1) {
          min[channel] = Math.min(min[channel], pixel[channel]);
          max[channel] = Math.max(max[channel], pixel[channel]);
        }
      });

      const ranges = max.map((value, channel) => value - min[channel]);
      this.splitChannel = ranges.indexOf(Math.max(...ranges));
      this.largestRange = ranges[this.splitChannel];
    }

    split() {
      if (this.pixels.length < 2) {
        return null;
      }

      const sorted = [...this.pixels].sort(
        (left, right) => left[this.splitChannel] - right[this.splitChannel],
      );
      const midpoint = Math.floor(sorted.length / 2);

      return [
        new ColorBox(sorted.slice(0, midpoint)),
        new ColorBox(sorted.slice(midpoint)),
      ];
    }

    averageColor() {
      const sum = [0, 0, 0, 0];

      this.pixels.forEach((pixel) => {
        for (let channel = 0; channel < 4; channel += 1) {
          sum[channel] += pixel[channel];
        }
      });

      return sum.map((value) => Math.round(value / this.pixels.length));
    }
  }

  function medianCutQuantization(rgba, colorCount) {
    const pixels = [];

    for (let index = 0; index < rgba.length; index += 4) {
      pixels.push([
        rgba[index],
        rgba[index + 1],
        rgba[index + 2],
        rgba[index + 3],
      ]);
    }

    let boxes = [new ColorBox(pixels)];

    while (boxes.length < colorCount) {
      const boxToSplit = boxes.reduce((current, candidate) =>
        current.largestRange > candidate.largestRange ? current : candidate,
      );
      boxes = boxes.filter((box) => box !== boxToSplit);
      const newBoxes = boxToSplit.split();

      if (!newBoxes) {
        boxes.push(boxToSplit);
        break;
      }

      boxes.push(...newBoxes);
    }

    const palette = boxes.map((box) => box.averageColor());
    quantizeToFixedPalette(rgba, palette);
  }

  function convertRgbaToPixelArt(source, width, height, options = {}) {
    const blockSize = options.blockSize || 6;
    const colorCount = options.colorCount || 16;
    const antiAliasThreshold = options.antiAliasThreshold || 30;
    const rgba = pixelateImageData(source, width, height, blockSize);
    const backgroundColor = detectBackgroundColor({
      width,
      height,
      data: rgba,
    });

    removeAntiAliasing(rgba, backgroundColor, antiAliasThreshold);
    medianCutQuantization(rgba, colorCount);

    return rgba;
  }

  const PixelCore = {
    convertRgbaToPixelArt,
    detectBackgroundColor,
    medianCutQuantization,
    pixelateImageData,
    quantizeToFixedPalette,
    removeAntiAliasing,
  };

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = PixelCore;
  }

  if (typeof globalThis !== 'undefined') {
    globalThis.PixelCore = PixelCore;
  }
})();
