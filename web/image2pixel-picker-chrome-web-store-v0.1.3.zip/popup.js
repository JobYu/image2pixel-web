function message(key) {
  return chrome.i18n.getMessage(key) || key;
}

const CONTENT_SCRIPT_FILES = [
  'src/pixel-core.js',
  'src/image-source.js',
  'content-script.js',
];
const CONTENT_STYLE_FILES = ['styles.css'];

function localizeDocument() {
  document.documentElement.lang = chrome.i18n.getUILanguage();
  document.querySelectorAll('[data-i18n]').forEach((node) => {
    node.textContent = message(node.dataset.i18n);
  });
  document.title = message('popupTitle');
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true,
  });

  if (!tab?.id) {
    throw new Error(message('errorCurrentPageMissing'));
  }

  return tab;
}

function setStatus(message, isError = false) {
  const element = document.getElementById('statusMessage');
  element.textContent = message;
  element.dataset.error = isError ? 'true' : 'false';
}

function syncValueLabels() {
  document.getElementById('blockSizeValue').textContent =
    document.getElementById('blockSize').value;
  document.getElementById('colorCountValue').textContent =
    document.getElementById('colorCount').value;
}

function getOptionsFromInputs() {
  return {
    blockSize: Number(document.getElementById('blockSize').value) || 8,
    colorCount: Number(document.getElementById('colorCount').value) || 16,
  };
}

async function saveOptions() {
  await chrome.storage.local.set({
    image2pixelOptions: getOptionsFromInputs(),
  });
}

function getOriginPattern(url) {
  try {
    const parsed = new URL(url);

    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return null;
    }

    return `${parsed.origin}/*`;
  } catch (_error) {
    return null;
  }
}

function getCurrentSiteLabel(url) {
  try {
    return new URL(url).origin;
  } catch (_error) {
    return message('permissionSiteUnavailable');
  }
}

async function refreshPermissionStatus(tab) {
  const currentSiteElement = document.getElementById('currentSite');
  const permissionStatusElement = document.getElementById('permissionStatus');
  const revokeButton = document.getElementById('revokeSitePermission');
  const originPattern = getOriginPattern(tab?.url);

  currentSiteElement.textContent = getCurrentSiteLabel(tab?.url || '');

  if (!originPattern) {
    permissionStatusElement.textContent = message('permissionStatusUnavailable');
    revokeButton.hidden = true;
    return;
  }

  const granted = await chrome.permissions.contains({
    origins: [originPattern],
  });

  permissionStatusElement.textContent = granted
    ? message('permissionStatusGranted')
    : message('permissionStatusNotGranted');
  revokeButton.hidden = !granted;
}

async function ensureContentScriptReady(tabId) {
  try {
    const response = await chrome.tabs.sendMessage(tabId, {
      type: 'PING_CONTENT_SCRIPT',
    });

    if (response?.ok) {
      return;
    }
  } catch (_error) {
    await chrome.scripting.insertCSS({
      target: { tabId },
      files: CONTENT_STYLE_FILES,
    });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: CONTENT_SCRIPT_FILES,
    });
  }
}

async function activatePicker() {
  const options = getOptionsFromInputs();
  await saveOptions();

  const tab = await getActiveTab();
  await ensureContentScriptReady(tab.id);
  const response = await chrome.tabs.sendMessage(tab.id, {
    type: 'PICK_IMAGE_FROM_PAGE',
    options,
  });

  if (!response?.ok) {
    throw new Error(message('errorPageNoResponse'));
  }

  setStatus(message('statusPickModeEnabled'));
}

async function revokeCurrentSitePermission() {
  const tab = await getActiveTab();
  const originPattern = getOriginPattern(tab.url);

  if (!originPattern) {
    return;
  }

  await chrome.permissions.remove({
    origins: [originPattern],
  });
  await refreshPermissionStatus(tab);
  setStatus(message('permissionRevoked'));
}

document.getElementById('activatePicker').addEventListener('click', async () => {
  try {
    await activatePicker();
  } catch (error) {
    setStatus(error.message, true);
  }
});

['blockSize', 'colorCount'].forEach((id) => {
  document.getElementById(id).addEventListener('input', () => {
    syncValueLabels();
    saveOptions().catch((error) => {
      setStatus(error.message, true);
    });
  });
});

document.getElementById('revokeSitePermission').addEventListener('click', async () => {
  try {
    await revokeCurrentSitePermission();
  } catch (error) {
    setStatus(error.message, true);
  }
});

localizeDocument();

chrome.storage.local.get(['image2pixelOptions']).then(({ image2pixelOptions }) => {
  const options = {
    blockSize: 8,
    colorCount: 16,
    ...(image2pixelOptions || {}),
  };

  document.getElementById('blockSize').value = options.blockSize;
  document.getElementById('colorCount').value = options.colorCount;
  syncValueLabels();
});

getActiveTab()
  .then((tab) => refreshPermissionStatus(tab))
  .catch((error) => {
    document.getElementById('currentSite').textContent = message('permissionSiteUnavailable');
    document.getElementById('permissionStatus').textContent = message('permissionStatusUnavailable');
    setStatus(error.message, true);
  });
