const DEFAULT_OPTIONS = {
  blockSize: 8,
  colorCount: 16,
};
const CONTENT_SCRIPT_FILES = [
  'src/pixel-core.js',
  'src/image-source.js',
  'content-script.js',
];
const CONTENT_STYLE_FILES = ['styles.css'];

function message(key) {
  return chrome.i18n.getMessage(key) || key;
}

function getOriginPattern(url) {
  try {
    const parsed = new URL(url);

    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return null;
    }

    return `${parsed.origin}/*`;
  } catch (_error) {
    return null;
  }
}

async function getStoredOptions() {
  const { image2pixelOptions } = await chrome.storage.local.get(['image2pixelOptions']);

  return {
    ...DEFAULT_OPTIONS,
    ...(image2pixelOptions || {}),
  };
}

function getFrameScope(frameId) {
  return typeof frameId === 'number'
    ? { frameIds: [frameId] }
    : { allFrames: false };
}

function getMessageOptions(frameId) {
  return typeof frameId === 'number'
    ? { frameId }
    : undefined;
}

async function hasHostPermission(url) {
  const originPattern = getOriginPattern(url);

  if (!originPattern) {
    return true;
  }

  return chrome.permissions.contains({
    origins: [originPattern],
  });
}

async function requestHostPermission(url) {
  const originPattern = getOriginPattern(url);

  if (!originPattern) {
    return true;
  }

  return chrome.permissions.request({
    origins: [originPattern],
  });
}

async function removeHostPermission(url) {
  const originPattern = getOriginPattern(url);

  if (!originPattern) {
    return true;
  }

  if (!await hasHostPermission(url)) {
    return true;
  }

  return chrome.permissions.remove({
    origins: [originPattern],
  });
}

async function ensureContentScriptReady(tabId, frameId) {
  const frameScope = getFrameScope(frameId);
  const messageOptions = getMessageOptions(frameId);

  try {
    await chrome.tabs.sendMessage(tabId, { type: 'PING_CONTENT_SCRIPT' }, messageOptions);
    return;
  } catch (_error) {
    await chrome.scripting.insertCSS({
      target: { tabId, ...frameScope },
      files: CONTENT_STYLE_FILES,
    });
    await chrome.scripting.executeScript({
      target: { tabId, ...frameScope },
      files: CONTENT_SCRIPT_FILES,
    });
  }
}

function createMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: 'image2pixel-convert-image',
      title: message('contextMenuConvertImage'),
      contexts: ['image'],
    });
  });
}

async function fetchImageAsDataUrl(url) {
  const response = await fetch(url, { credentials: 'omit' });

  if (!response.ok) {
    throw new Error(`Failed to fetch image: ${response.status}`);
  }

  const contentType = response.headers.get('content-type') || 'image/png';
  const bytes = new Uint8Array(await response.arrayBuffer());
  let binary = '';

  bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });

  return `data:${contentType};base64,${btoa(binary)}`;
}

chrome.runtime.onInstalled.addListener(() => {
  createMenus();
});

chrome.runtime.onStartup.addListener(() => {
  createMenus();
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== 'image2pixel-convert-image' || !tab?.id) {
    return;
  }

  const granted = await requestHostPermission(info.srcUrl);

  if (!granted) {
    return;
  }

  const options = await getStoredOptions();
  const frameId = typeof info.frameId === 'number' ? info.frameId : undefined;
  const messageOptions = getMessageOptions(frameId);
  await ensureContentScriptReady(tab.id, frameId);
  await chrome.tabs.sendMessage(tab.id, {
    type: 'CONVERT_CONTEXT_IMAGE',
    imageUrl: info.srcUrl,
    options,
  }, messageOptions);
});

chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  if (request?.type === 'REQUEST_IMAGE_HOST_PERMISSION' && request.url) {
    hasHostPermission(request.url)
      .then((granted) => sendResponse({
        ok: granted,
        error: granted ? undefined : 'Host permission missing',
      }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));

    return true;
  }

  if (request?.type === 'REMOVE_IMAGE_HOST_PERMISSION' && request.url) {
    removeHostPermission(request.url)
      .then((removed) => sendResponse({ ok: removed }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));

    return true;
  }

  if (request?.type !== 'FETCH_IMAGE_AS_DATA_URL' || !request.url) {
    return undefined;
  }

  fetchImageAsDataUrl(request.url)
    .then((dataUrl) => sendResponse({ ok: true, dataUrl }))
    .catch((error) => sendResponse({ ok: false, error: error.message }));

  return true;
});
