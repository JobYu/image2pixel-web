const conversionState = {
  picking: false,
  hoveredImage: null,
  options: {
    blockSize: 8,
    colorCount: 16,
  },
  banner: null,
  bannerHideTimer: null,
};

function message(key) {
  return chrome.i18n.getMessage(key) || key;
}

function recommendationHtml() {
  return `${message('recommendationPrefix')} <a href="https://image2pixel.app" target="_blank" rel="noreferrer">image2pixel.app</a>`;
}

function formatConversionError(error) {
  const raw = String(error?.message || error || '').trim();

  if (raw === 'Host permission missing') {
    return `${message('errorHostPermissionMissing')} ${message('errorAdviceGrantSitePermission')}`;
  }

  if (raw === 'Google image source not resolved') {
    return `${message('errorGoogleImageSourceNotResolved')} ${message('errorAdviceOpenOriginalImage')}`;
  }

  if (raw === 'Baidu image source not resolved') {
    return `${message('errorBaiduImageSourceNotResolved')} ${message('errorAdviceOpenOriginalImage')}`;
  }

  if (raw === 'Image source not resolved') {
    return `${message('errorImageSourceNotResolved')} ${message('errorAdviceOpenOriginalImage')}`;
  }

  if (raw.startsWith('Failed to fetch image: 403')) {
    return `${message('errorFetch403')} ${message('errorAdviceOpenOriginalImage')}`;
  }

  if (raw.startsWith('Failed to fetch image: 404')) {
    return `${message('errorFetch404')} ${message('errorAdviceReloadOrOpenOriginalImage')}`;
  }

  if (raw.startsWith('Failed to fetch image:')) {
    return `${message('errorFetchGeneric')} ${message('errorAdviceOpenOriginalImage')}`;
  }

  return raw || message('errorConversionUnknown');
}

function ensureBanner() {
  if (conversionState.banner) {
    return conversionState.banner;
  }

  const banner = document.createElement('div');
  banner.className = 'image2pixel-banner';
  banner.innerHTML = `<span>${recommendationHtml()}</span>`;
  document.documentElement.appendChild(banner);
  conversionState.banner = banner;
  return banner;
}

function setBannerStatus(message, isError = false, autoHideMs = 0) {
  const banner = ensureBanner();
  clearTimeout(conversionState.bannerHideTimer);
  conversionState.bannerHideTimer = null;
  banner.hidden = false;
  banner.dataset.error = isError ? 'true' : 'false';
  banner.querySelector('span').innerHTML = message;

  if (autoHideMs > 0) {
    conversionState.bannerHideTimer = setTimeout(() => {
      banner.hidden = true;
      conversionState.bannerHideTimer = null;
    }, autoHideMs);
  }
}

function updateOptions(options = {}) {
  conversionState.options = {
    ...conversionState.options,
    ...options,
  };
}

function getClosestImageTarget(target) {
  if (target instanceof Element) {
    return target.closest('img');
  }

  return null;
}

function clearHoveredImage() {
  if (!conversionState.hoveredImage) {
    return;
  }

  conversionState.hoveredImage.classList.remove('image2pixel-hover');
  conversionState.hoveredImage = null;
}

function disablePickMode() {
  conversionState.picking = false;
  clearHoveredImage();
  document.documentElement.classList.remove('image2pixel-picker-active');
}

function enablePickMode(options = {}) {
  updateOptions(options);
  conversionState.picking = true;
  document.documentElement.classList.add('image2pixel-picker-active');
  setBannerStatus(
    message('pickModeEnabled'),
  );
}

function getImageSource(element) {
  return globalThis.ImageSourceState.resolveOriginalImageSource(
    globalThis.ImageSourceState.buildSourceState(element),
  );
}

function requestImageDataUrl(url) {
  if (!url) {
    throw new Error('Missing image URL');
  }

  if (url.startsWith('data:')) {
    return Promise.resolve(url);
  }

  return chrome.runtime.sendMessage({
    type: 'REQUEST_IMAGE_HOST_PERMISSION',
    url,
  }).then((permissionResponse) => {
    if (!permissionResponse?.ok) {
      throw new Error(permissionResponse?.error || 'Host permission missing');
    }

    return chrome.runtime.sendMessage({
      type: 'FETCH_IMAGE_AS_DATA_URL',
      url,
    });
  }).then((response) => {
    if (!response?.ok) {
      throw new Error(response?.error || 'Unable to fetch image');
    }

    return response.dataUrl;
  });
}

function loadImage(dataUrl) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Image load failed'));
    image.src = dataUrl;
  });
}

function getImageDataFromRenderedImage(imageElement) {
  const canvas = document.createElement('canvas');
  const context = canvas.getContext('2d', { willReadFrequently: true });

  canvas.width = imageElement.naturalWidth || imageElement.width;
  canvas.height = imageElement.naturalHeight || imageElement.height;
  context.imageSmoothingEnabled = false;
  context.drawImage(imageElement, 0, 0);

  return {
    canvas,
    context,
    imageData: context.getImageData(0, 0, canvas.width, canvas.height),
  };
}

function buildResolvedSourceState(imageElement) {
  const sourceState = globalThis.ImageSourceState.buildSourceState(imageElement);
  const originalSourceUrl = globalThis.ImageSourceState.resolveOriginalImageSource(sourceState);

  return {
    sourceState,
    originalSourceUrl,
    isGoogleImagesPage: globalThis.ImageSourceState.isGoogleImagesPage(
      imageElement?.ownerDocument?.location || globalThis.location,
    ),
    isBaiduImagesPage: globalThis.ImageSourceState.isBaiduImagesPage(
      imageElement?.ownerDocument?.location || globalThis.location,
    ),
  };
}

async function getImageDataWithFallback(imageElement) {
  const {
    sourceState,
    originalSourceUrl,
    isGoogleImagesPage,
    isBaiduImagesPage,
  } = buildResolvedSourceState(imageElement);

  if (sourceState.originalDataUrl) {
    const sourceImage = await loadImage(sourceState.originalDataUrl);
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d', { willReadFrequently: true });

    canvas.width = sourceImage.naturalWidth || sourceImage.width;
    canvas.height = sourceImage.naturalHeight || sourceImage.height;
    context.imageSmoothingEnabled = false;
    context.drawImage(sourceImage, 0, 0);

    return {
      canvas,
      context,
      imageData: context.getImageData(0, 0, canvas.width, canvas.height),
      originalSourceUrl,
      originalDataUrl: sourceState.originalDataUrl,
    };
  }

  try {
    const rendered = getImageDataFromRenderedImage(imageElement);

    return {
      ...rendered,
      originalSourceUrl,
      originalDataUrl: rendered.canvas.toDataURL('image/png'),
    };
  } catch (_error) {
    if (!originalSourceUrl) {
      throw new Error(
        isGoogleImagesPage
          ? 'Google image source not resolved'
          : isBaiduImagesPage
            ? 'Baidu image source not resolved'
            : 'Image source not resolved',
      );
    }

    const dataUrl = await requestImageDataUrl(originalSourceUrl);
    const sourceImage = await loadImage(dataUrl);
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d', { willReadFrequently: true });

    canvas.width = sourceImage.naturalWidth || sourceImage.width;
    canvas.height = sourceImage.naturalHeight || sourceImage.height;
    context.imageSmoothingEnabled = false;
    context.drawImage(sourceImage, 0, 0);

    return {
      canvas,
      context,
      imageData: context.getImageData(0, 0, canvas.width, canvas.height),
      originalSourceUrl,
      originalDataUrl: dataUrl,
    };
  }
}

async function convertImageElement(imageElement) {
  const {
    canvas,
    context,
    imageData,
    originalSourceUrl,
    originalDataUrl,
  } = await getImageDataWithFallback(imageElement);
  const converted = globalThis.PixelCore.convertRgbaToPixelArt(
    imageData.data,
    imageData.width,
    imageData.height,
    conversionState.options,
  );

  context.putImageData(
    new ImageData(converted, imageData.width, imageData.height),
    0,
    0,
  );

  imageElement.dataset.image2pixelOriginalSrc = originalSourceUrl;
  imageElement.dataset.image2pixelOriginalDataUrl = originalDataUrl;
  imageElement.srcset = '';
  imageElement.src = canvas.toDataURL('image/png');
}

function findImageByUrl(imageUrl) {
  return Array.from(document.images).find((image) => {
    const source = getImageSource(image);
    return source === imageUrl || image.src === imageUrl;
  }) || null;
}

async function convertSingleImageByUrl(imageUrl, options = {}) {
  updateOptions(options);
  const image = findImageByUrl(imageUrl);

  if (!image) {
    throw new Error(message('errorImageNotFound'));
  }

  await convertImageElement(image);
  return 1;
}

document.addEventListener(
  'mouseover',
  (event) => {
    if (!conversionState.picking) {
      return;
    }

    const image = getClosestImageTarget(event.target);
    if (!image) {
      clearHoveredImage();
      return;
    }

    if (conversionState.hoveredImage !== image) {
      clearHoveredImage();
      conversionState.hoveredImage = image;
      image.classList.add('image2pixel-hover');
    }
  },
  true,
);

document.addEventListener(
  'click',
  async (event) => {
    if (!conversionState.picking) {
      return;
    }

    const image = getClosestImageTarget(event.target);
    if (!image) {
      return;
    }

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    setBannerStatus(message('pickModeConverting'));

    try {
      await convertImageElement(image);
      disablePickMode();
      setBannerStatus(message('pickModeDone'), false, 3000);
    } catch (error) {
      disablePickMode();
      setBannerStatus(
        `${message('pickModeFailedPrefix')}${formatConversionError(error)}`,
        true,
      );
    }
  },
  true,
);

document.addEventListener(
  'keydown',
  (event) => {
    if (event.key === 'Escape' && conversionState.picking) {
      disablePickMode();
      setBannerStatus(
        `${message('pickModeCanceled')} ${recommendationHtml()}`,
      );
    }
  },
  true,
);

chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  if (request?.type === 'PING_CONTENT_SCRIPT') {
    sendResponse({ ok: true });
    return undefined;
  }

  if (request?.type === 'PICK_IMAGE_FROM_PAGE') {
    enablePickMode(request.options);
    sendResponse({ ok: true });
    return undefined;
  }

  if (request?.type === 'CONVERT_CONTEXT_IMAGE') {
    setBannerStatus(message('pickModeConverting'));
    convertSingleImageByUrl(request.imageUrl, request.options)
      .then(() => {
        setBannerStatus(message('pickModeDone'), false, 3000);
        sendResponse({ ok: true });
      })
      .catch((error) => {
        setBannerStatus(
          `${message('pickModeFailedPrefix')}${formatConversionError(error)}`,
          true,
        );
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }
});
